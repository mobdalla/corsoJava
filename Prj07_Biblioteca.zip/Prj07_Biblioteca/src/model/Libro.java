package model;

public class Libro {
	private String titolo;
	private String autore;
	boolean inPrestito=false;
	public Libro(String titolo, String autore) {
		this.titolo = titolo;
		this.autore = autore;
		this.inPrestito = inPrestito;
	}
	public String  getDescrizione() {
		String descrizione=titolo+" "+autore;
		
		return descrizione; 
	}
	public boolean isInPrestio() {
		boolean p=false;
		if(inPrestito==true) {
			p=true;
		}
		return p;
	}
	public  void setInPrestito(boolean stato) {
			this.inPrestito = stato;
	}
	public String getTitolo() {
		return titolo;
	}
	public void EccezioneLibro(int key) {
		System.out.println(key);
		switch (key) {
			case 1: {
				System.err.println("libro in prestito");
				break;
				}
			case 2: {
				System.err.println("libro non presenti nel biblioteca");
				break;
				}
	
	}
	}
	
	
	
}
