package model;
import java.util.ArrayList;

import model.Libro;
public class Biblioteca {
	private String nome;
	private ArrayList<Libro> model;

	public Biblioteca(String nome) {
		this.nome =nome;
		this.model= new ArrayList<Libro>();
	}
	public void  addlibro(Libro l){
	
		model.add(l);
	}
	
	public void prestato(Libro l) {
		int t=1;
		for (Libro libro : model) {
			if(libro.getTitolo()!=l.getTitolo()) {

				t=0;
			}
			else {
				if(libro.inPrestito == true ) {
					l.EccezioneLibro(1);
				
				}else {
					l.setInPrestito(true);
					t=0;
					break;
				}
			}
		}
		if(t==0) {
			l.EccezioneLibro(2);
		}
	}
	public boolean inBilioteca(Libro l) {
		boolean b=false;
		for (Libro libro : model) {
			if(l.getTitolo()== libro.getTitolo()) {
				 b=true;
			 }
		}
		 return b;
	 }
	public int totInPrestito() {
		int i=0;
		for (Libro libro : model) {
			if(libro.inPrestito == true) {
				i++;
			}
		}
		return i;
	}
	public boolean nessunPrestito() {
		boolean k=false;
		if(totInPrestito() == 0) {
			k=true;
		}
		return k;
	}
	public void restituito(Libro l) {
		l.setInPrestito(false);
	}
	public int perBambini(int etaMax) {
		int  g= 0;
		for (Libro libro : model) {
			if (libro instanceof LibriPerBambini) {
				
				if(etaMax >=LibriPerBambini.getEtaConsigliata()) {
					
					g++;
				}
			}
		}
		return g;
	}
}
