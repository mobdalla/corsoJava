package model;

public class LibriPerBambini extends Libro {
	 private static int  etaConsigliata;
	public LibriPerBambini(String titolo, String autore , int etaConsigliata) {
		super(titolo, autore);
		LibriPerBambini.etaConsigliata= etaConsigliata;
		// TODO Auto-generated constructor stub
	}
	
	

	@Override
	public String getDescrizione() {
		return "eta consigliata: "+etaConsigliata+ " "+  super.getDescrizione();
	}
	


	public static void setEtaConsigliata(int etaConsigliata) {
		LibriPerBambini.etaConsigliata = etaConsigliata;
	}



	public static int getEtaConsigliata() {
		return etaConsigliata;
	}
	
	
}
